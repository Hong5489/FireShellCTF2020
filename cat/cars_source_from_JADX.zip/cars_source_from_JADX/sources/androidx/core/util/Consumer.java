package androidx.core.util;

public interface Consumer<T> {
    void accept(T t);
}
